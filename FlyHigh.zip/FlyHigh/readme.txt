Steps:-

1) Import DATABASEFILE/user_db database into phpmyadmin
2) Goto https://localhost/FlyHigh/